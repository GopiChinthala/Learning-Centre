﻿CREATE PROCEDURE [190513].[GetDesignationsHRDS]
	
AS
Begin
	SELECT * from [190513].Designation_HRDS
End

