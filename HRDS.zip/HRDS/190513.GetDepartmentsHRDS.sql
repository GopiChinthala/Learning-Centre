﻿CREATE PROCEDURE [190513].[GetDepartmentsHRDS]
	
AS
Begin
	SELECT * from [190513].Department_HRDS
End