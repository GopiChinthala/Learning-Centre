Create Table [190513].Designation_HRDS
(
ID int primary key,
Name varchar(50)
)

Create Table [190513].Department_HRDS
(
ID int primary key,
Name varchar(50),
Head varchar(50),
Location varchar(50)
)

Create Table [190513].Employee_HRDS
(
ID int primary key,
Name varchar(50),
Designation int,
Department int
)

select * from [190513].Designation_HRDS
select * from [190513].Department_HRDS
select * from [190513].Employee_HRDS