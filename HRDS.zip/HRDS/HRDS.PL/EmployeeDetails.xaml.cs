﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using HRDS.BusinessLayer;
using HRDS.Entities;
using HRDS.Exceptions;

namespace HRDS.PL
{
    /// <summary>
    /// Interaction logic for EmployeeDetails.xaml
    /// </summary>
    public partial class EmployeeDetails : Window
    {
        public EmployeeDetails()
        {
            InitializeComponent();
        }

        private bool ValidateUI()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (txtId.Text == null || txtId.Text == string.Empty)
            {
                isValid = false;
                sb.Append("ID is Empty!" + Environment.NewLine);
            }
            if (txtName.Text == string.Empty | txtName.Text.Length < 1)
            {
                isValid = false;
                sb.Append("Name is Empty!" + Environment.NewLine);
            }
            if (cmbDesignations.SelectedIndex<0)
            {
                isValid = false;
                sb.Append("Designation is Empty!" + Environment.NewLine);
            }
            if (cmbDepartments.SelectedIndex<0 )
            {
                isValid = false;
                sb.Append("Department is Empty!" + Environment.NewLine);
            }
                   
            if (!isValid)
            {
                throw new HRDSException(sb.ToString());
            }

            return isValid;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDesignations();
            GetDepartments();
        }

        private void BtnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            AddEmployee();
        }

        private void BtnUpdateEmployee_Click(object sender, RoutedEventArgs e)
        {
            UpdateEmployee();
        }

        private void BtnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            DeleteEmployee();
        }

        private void BtnSearchEmployee_Click(object sender, RoutedEventArgs e)
        {
            SearchEmployee();
        }

        private void BtnGetAllEmployee_Click(object sender, RoutedEventArgs e)
        {
            GetEmployees();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void AddEmployee()
        {
            try
            {

                int id;
                string name;
                int designationid;
                int departmentid;
                bool employeeAdded;
                //
                if (ValidateUI())
                {
                    id = Convert.ToInt32(txtId.Text);
                    name = txtName.Text;
                    designationid = Convert.ToInt32(cmbDesignations.SelectedValue);
                    departmentid = Convert.ToInt32(cmbDepartments.SelectedValue);
                    //


                    Employee objEmployee = new Employee
                    {
                        Id = id,
                        Name = name,
                        Designation = designationid,
                        Department = departmentid
                    };
                    employeeAdded = EmployeeBL.AddEmployeeBL(objEmployee);
                    if (employeeAdded == true)
                    {
                        MessageBox.Show("Employee record Added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Employee record not Added successfully.");
                    }
                }
                else
                {
                    MessageBox.Show("Validation Error!");
                }
            }
            catch (HRDSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void UpdateEmployee()
        {
            try
            {

                int id;
                string name;
                int designationid;
                int departmentid;
                bool employeeUpdated;
                //
                if (ValidateUI())
                {
                    id = Convert.ToInt32(txtId.Text);
                    name = txtName.Text;
                    designationid = Convert.ToInt32(cmbDesignations.SelectedValue);
                    departmentid = Convert.ToInt32(cmbDepartments.SelectedValue);
                    //
                    Employee objEmployee = new Employee
                    { Id = id, Name = name, Designation = designationid, Department = departmentid };
                    employeeUpdated = EmployeeBL.UpdateEmployeeBL(objEmployee);
                    if (employeeUpdated == true)
                    {
                        MessageBox.Show("Employee record Updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Employee record not updated successfully.");
                    }
                }
                else
                {
                    MessageBox.Show("Validation Error!");
                }
            }
            catch (HRDSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void DeleteEmployee()
        {
            try
            {
                int id;
                //
                bool employeeDeleted;
                //
                if (txtId.Text != null && txtId.Text != string.Empty)
                {
                    id = Convert.ToInt32(txtId.Text);
                    //
                    employeeDeleted = EmployeeBL.DeleteEmployeeBL(id);
                    if (employeeDeleted == true)
                    {
                        MessageBox.Show("Employee record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Employee record not deleted successfully.");
                    }
                }
                else
                {
                    MessageBox.Show("Id is Empty!");
                }
            }
            catch (HRDSException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch(Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void SearchEmployee()
        {
            try
            {
                int id;
                //
                Employee objEmployee;
                //
                if (txtId.Text != null && txtId.Text != string.Empty)
                {
                    id = Convert.ToInt32(txtId.Text);
                    //
                    objEmployee = EmployeeBL.SearchEmployeeBL(id);
                    if (objEmployee != null)
                    {
                        txtName.Text = objEmployee.Name;
                        cmbDesignations.SelectedValue = objEmployee.Designation;
                        cmbDepartments.SelectedValue = objEmployee.Department;
                    }
                    else
                    {
                        MessageBox.Show("Employee record couldn't be found.");
                    }
                }
                else
                {
                    MessageBox.Show("ID is Empty!");
                }
            }
            catch (HRDSException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void GetEmployees()
        {
            try
            {
                List<Employee> objEmployees = EmployeeBL.GetAllEmployeesBL();
                if (objEmployees != null)
                {
                    dgEmployees.ItemsSource = objEmployees;
                }
                else
                {
                    MessageBox.Show("No record available.");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void GetDesignations()
        {
            try
            {
                DataTable designationList = EmployeeBL.GetDesignationsBL();
                cmbDesignations.ItemsSource = designationList.DefaultView;
                cmbDesignations.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbDesignations.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (HRDSException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void GetDepartments()
        {
            try
            {
                DataTable departmentList = EmployeeBL.GetDepartmentsBL();
                cmbDepartments.ItemsSource = departmentList.DefaultView;
                cmbDepartments.DisplayMemberPath = departmentList.Columns[1].ColumnName;
                cmbDepartments.SelectedValuePath = departmentList.Columns[0].ColumnName;
            }
            catch (HRDSException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void Clear()
        {
            txtId.Clear();
            txtName.Clear();
            cmbDesignations.SelectedIndex = -1;
            cmbDepartments.SelectedIndex = -1;
            dgEmployees.DataContext = null;
        }

        
    }
}
