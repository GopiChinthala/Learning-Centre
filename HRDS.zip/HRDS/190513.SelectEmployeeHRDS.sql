﻿CREATE PROCEDURE [190513].[SelectEmployeeHRDS]
	@ID int,
	@Name varchar(50) output,
	@Designation int output,
	@Department int output
AS
Begin
	Select 
	Name = @Name,
	Designation = @Designation,
	Department = @Department
	From [190513].Employee_HRDS
	where ID = @ID
End

GO