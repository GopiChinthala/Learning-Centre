﻿CREATE PROCEDURE [190513].[UpdateEmployeeHRDS]
	@ID int,
	@Name varchar(50),
	@Designation int,
	@Department int
AS
Begin
	Update [190513].Employee_HRDS set
	Name = @Name,
	Designation = @Designation,
	Department = @Department
	where ID = @ID

End

GO