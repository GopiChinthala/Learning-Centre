﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRDS.Exceptions
{
    public class HRDSException : ApplicationException

    {
        public HRDSException() : base()
        {

        }
        public HRDSException(string message) : base(message)
        {

        }
        public HRDSException(string message, Exception innerException) : base(innerException: innerException, message: message) //is tarike se krne pe humen order of parameters in base class ki zrurt ko dhyan me nhi rakhna padta
        {

        }
    }
}
