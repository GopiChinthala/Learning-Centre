﻿CREATE PROCEDURE [190513].[SelectEmployeesHRDS]
AS
Begin
	Select * From [190513].Employee_HRDS
End
GO