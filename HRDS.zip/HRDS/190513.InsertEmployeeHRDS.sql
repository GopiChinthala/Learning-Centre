﻿CREATE PROCEDURE [190513].[InsertEmployeeHRDS]
	@ID int,
	@Name varchar(50),
	@Designation int,
	@Department int
AS
Begin
	Insert into [190513].Employee_HRDS values(@ID, @Name, @Designation, @Department)
End

GO
