﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.Entities;
using HRDS.DataAccessLayer;
using HRDS.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;

namespace HRDS.BusinessLayer
{
    public class EmployeeBL
    {
        public static bool Validation(Employee employee)
        {
            bool isvalid = true;
            StringBuilder str = new StringBuilder();
            if (!Regex.Match(employee.Name, "^[A-Z][A-Za-z]*$").Success)
            {
                isvalid = false;
                str.Append("\nName should not contain Numbers.");
            }
            if (!Regex.Match(employee.Id.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                str.Append("\nID should be in Numbers.");
            }
            if (!Regex.Match(employee.Designation.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                str.Append("\nDesignation number should be in Numbers.");
            }
            if (!Regex.Match(employee.Department.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                str.Append("\nDepartment number should be in Numbers.");
            }
            if (isvalid == false)
            {
                throw new HRDSException(str.ToString());
            }
            return isvalid;
        }

        public static bool AddEmployeeBL(Employee employee)
        {
            bool employeeAdded = false;
           
            try
            {
                if (Validation(employee))
                {
                    EmployeeDAL objDAL = new EmployeeDAL();
                    employeeAdded = objDAL.AddEmployeeDAL(employee);
                }
                
            }
            catch (HRDSException ex)
            {
                throw ex;
            }
            return employeeAdded;
        }

        public static bool UpdateEmployeeBL(Employee employee)
        {
            bool employeeUpdated = false;
            try
            {
                if (Validation(employee))
                {
                    EmployeeDAL objDAL = new EmployeeDAL();
                    employeeUpdated = objDAL.UpdateEmployeeDAL(employee);
                }
            }
            catch (HRDSException ex)
            {
                throw ex;
            }
            return employeeUpdated;
        }

        public static bool DeleteEmployeeBL(int id)
        {
            bool employeeDeleted = false;
            try
            {
                if (id>0)
                {
                    EmployeeDAL objDAL = new EmployeeDAL();
                    employeeDeleted = objDAL.DeleteEmployeeDAL(id);
                }
            }
            catch (HRDSException ex)
            {
                throw ex;
            }
            return employeeDeleted;
        }

        public static Employee SearchEmployeeBL(int id)
        {
            Employee employeeSearch = null;
            try
            {
                if (id > 0)
                {
                    EmployeeDAL objDAL = new EmployeeDAL();
                    employeeSearch = objDAL.SearchEmployeeDAL(id);
                }
            }
            catch (HRDSException ex)
            {
                throw ex;
            }
            return employeeSearch;
        }

        public static List<Employee> GetAllEmployeesBL()
        {
            List<Employee> employeeGetAll = null;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                employeeGetAll = objDAL.GetAllEmployeesDAL();
            }
            catch (HRDSException ex)
            {
                throw ex;
            }
            return employeeGetAll;
        }

        public static DataTable GetDesignationsBL()
        {
            DataTable designationList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                designationList = employeeDAL.GetDesignationsDAL();
            }
            catch (HRDSException ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return designationList;
        }

        public static DataTable GetDepartmentsBL()
        {
            DataTable departmentList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                departmentList = employeeDAL.GetDepartmentsDAL();
            }
            catch (HRDSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return departmentList;
        }
    }
}
