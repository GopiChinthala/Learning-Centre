﻿

CREATE PROCEDURE [190513].[DeleteEmployeeHRDS]
	@ID int
AS
Begin
	Delete [190513].Employee_HRDS where ID = @ID
End

GO