﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ShubhamServiceLibrary1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        void Add(Employee obj);
        [OperationContract]
        void Update(Employee obj);
        [OperationContract]
        void Remove(int empid);
        [OperationContract]
        List<Employee> GetAll();
        [OperationContract]
        Employee Search(int empid);

        // TODO: Add your service operations here
    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    // You can add XSD files into the project. After building the project, you can directly use the data types defined there, with the namespace "MTTServiceLayer.ContractType".
    [DataContract]
    public class Employee
    {

        private int empid;
        [DataMember]
        public int Empid
        {
            get { return empid; }
            set { empid = value; }
        }
        private string empname;
        [DataMember]
        public string empName
        {
            get { return empname; }
            set { empname = value; }
        }

        private DateTime doj;
        [DataMember]
        public DateTime DoJ
        {
            get { return doj; }
            set { doj = value; }
        }

        private double salary;
        [DataMember]
        public double Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        private string address;
        [DataMember]
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

    }
}
