﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace ShubhamServiceLibrary1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        public Service1()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }
        public void Add(Employee obj)
        {
            try
            {
                cmd = new SqlCommand("insert into [A132419].[Employee] values(@empName, @doj, @salary, @address)", cn);
                cmd.Parameters.AddWithValue("@empName", obj.empName);
                cmd.Parameters.AddWithValue("@doj", obj.DoJ);
                cmd.Parameters.AddWithValue("@salary", obj.Salary);
                cmd.Parameters.AddWithValue("@address", obj.Address);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public List<Employee> GetAll()
        {
            List<Employee> employees = new List<Employee>();
            try
            {
                cmd = new SqlCommand("select * from [A132419].[Employee]", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee emp = new Employee
                    {
                        Empid = Convert.ToInt32(dr[0]),
                        empName = dr[1].ToString(),
                        DoJ = Convert.ToDateTime(dr[2]),
                        Salary = Convert.ToInt32(dr[3]),
                        Address = dr[4].ToString()
                    };
                    employees.Add(emp);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return employees;
        }

        public void Remove(int empid)
        {
            try
            {
                cmd = new SqlCommand("delete from [A132419].[Employee] where EmpId=@empId", cn);
                cmd.Parameters.AddWithValue("@empId", empid);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public Employee Search(int empid)
        {
            Employee employees = null;
            try
            {
                cmd = new SqlCommand("select * from [A132419].[Employee] where EmpId=@empId", cn);
                cmd.Parameters.AddWithValue("@empId", empid);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    employees = new Employee
                    {
                        Empid = Convert.ToInt32(dr[0]),
                        empName = dr[1].ToString(),
                        DoJ = Convert.ToDateTime(dr[2]),
                        Salary = Convert.ToInt32(dr[3]),
                        Address = dr[4].ToString()
                    };

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return employees;
        }

        public void Update(Employee obj)
        {
            try
            {
                cmd = new SqlCommand("update [A132419].[Employee] set EmpName=@empName, doj=@doj, Salary=@salary, Address=@address where EmpId=@empId", cn);
                cmd.Parameters.AddWithValue("@empId", obj.Empid);
                cmd.Parameters.AddWithValue("@empName", obj.empName);
                cmd.Parameters.AddWithValue("@doj", obj.DoJ);
                cmd.Parameters.AddWithValue("@salary", obj.Salary);
                cmd.Parameters.AddWithValue("@address", obj.Address);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
    }
}
