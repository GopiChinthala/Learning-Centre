﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lenovo_Service_Center1.Businesslayer;
using Lenovo_Service_Center1.Entities;
using Lenovo_Service_Center1.Exceptions;
using Lenovo_Service_Center1.DataAccessLayer;
namespace Lenovo_Service_Center1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private bool ValidateUI()
        {
            bool isvalid = true;
            StringBuilder sb = new StringBuilder();
            if(txtServiceID.Text==null||txtServiceID.Text==string.Empty)
            {
                isvalid = false;
                sb.Append("ServiceID is not proper format" + Environment.NewLine);
            }

            if(!isvalid)
            {
                throw new ServiceException(sb.ToString());
            }
            return isvalid;
        }

        private void BtnSubmitRequest_Click(object sender, RoutedEventArgs e)
        {
            AddService();

        }

        private void AddService()
        {
            try
            {
                string serviceID;
                DateTime date;
                string ownerName;
                string devicetype;
                string contactNo;
                string discripton;
                int serialNo;
                bool serviceAdded;
                //
                if (ValidateUI())
                {
                    serviceID = txtServiceID.Text;
                    ownerName = txtOwnerName.Text;
                    devicetype = ((ListBoxItem)lbType.SelectedItem).Content.ToString();
                    date = (DateTime)txtDate.SelectedDate;
                    serialNo = Convert.ToInt32(txtSerialNo);
                    contactNo = txtContactNo.Text;
                    discripton = txtDescription.Selection.Text;
                    ///
                    Service objService = new Service
                    {
                        ServiceID = serviceID,
                        Date = date,
                        DeviceType = devicetype,
                        OwnerName = ownerName,
                        SerialNo = serialNo,
                        ContactNo = contactNo,
                        IssueDescription = discripton
                     };
                    serviceAdded = ServiceBL.AddServiceBL(objService);
                    if(serviceAdded==true)
                    {
                        MessageBox.Show("Issue Added Succesfully");

                    }
                    else
                    {
                        MessageBox.Show("Issue not Added");

                    }

                }


                else
                {
                    MessageBox.Show("Validation Error");
                }


            }
           catch (ServiceException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
