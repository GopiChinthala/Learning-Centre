﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lenovo_Service_Center1.Entities;
using Lenovo_Service_Center1.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Lenovo_Service_Center1.DataAccessLayer
{
    public class ServiceDAL
    {
        public bool AddServiceDAL(Service objService)
        {

            bool serviceAdded = false;
            SqlConnection objCon=null;
            SqlCommand objCom = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["LenovoserviceCenter"].ConnectionString);
                objCom = new SqlCommand("Gopi190207.[Insert_IssueDiscription]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_ServiceID = new SqlParameter("@ServiceID", objService.ServiceID);
                SqlParameter objSqlParam_Date = new SqlParameter("@Name", objService.Date);
                SqlParameter objSqlParam_OwnerName = new SqlParameter("@OwnerName", objService.OwnerName);
                SqlParameter objSqlParam_ContactNo= new SqlParameter("@ContactNo", objService.ContactNo);
                SqlParameter objSqlParam_DeviceType = new SqlParameter("@DeviceType", objService.DeviceType);
                SqlParameter objSqlParam_SerialNo = new SqlParameter("@ServiceNo", objService.SerialNo);
                SqlParameter objSqlParam_IssueDiscription = new SqlParameter("@IssueDiscription", objService.IssueDescription);
                //
                objCom.Parameters.Add(objSqlParam_ServiceID);
                objCom.Parameters.Add(objSqlParam_Date);
                objCom.Parameters.Add(objSqlParam_OwnerName);
                objCom.Parameters.Add(objSqlParam_ContactNo);
                objCom.Parameters.Add(objSqlParam_DeviceType);
                objCom.Parameters.Add(objSqlParam_SerialNo);
                objCom.Parameters.Add(objSqlParam_IssueDiscription);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                serviceAdded = true;

            }
            catch (SqlException onjsqlEx)
            {

                throw new ServiceException(onjsqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return serviceAdded;

        }

        public List<Service> GetAllServicesDAL()
        {
            //make Connection
            SqlConnection objCon=null;
            List<Service> objServices = new List<Service>();
            SqlCommand objcom = new SqlCommand("Gopi190207.");


        }







    
}
