﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lenovo_Service_Center1.DataAccessLayer;
using Lenovo_Service_Center1.Entities;
using Lenovo_Service_Center1.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Lenovo_Service_Center1.Businesslayer
{
    public class ServiceBL
    {
        public static bool Validation(Service service)
        {
            bool isvalid = true;
            StringBuilder str= new StringBuilder();
            if(!Regex.Match(service.ServiceID,"^[A-Z]{2}_[0-9]{6}*$").Success)
            {
                isvalid = false;
               str.Append("\n Name should be 2capital and remaining are numbers");

            }

            return isvalid;

        }

        public static bool AddServiceBL(Service service)
        {
            bool serviceAdded = false;
            try
            {
                if(Validation(service))
                {
                    ServiceDAL objDAL = new ServiceDAL();
                    serviceAdded = objDAL.AddServiceDAL(service);
                }

            }
            catch (ServiceException Ex)
            {

                throw Ex;
            }
            return serviceAdded;
        }


    }
}
