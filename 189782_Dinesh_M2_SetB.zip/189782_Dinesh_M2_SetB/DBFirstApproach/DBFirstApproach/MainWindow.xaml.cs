﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DBFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DBFAEntities obj1;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Btn_display_Click(object sender, RoutedEventArgs e)
        {
            obj1 = new DBFAEntities();
            getdetails();
        }

        private void getdetails()
        {
            var serviceReq = from service in obj1.ServiceRequest_LRC
                             where service.DeviceType == cb_dbfa.Text//((ComboBoxItem)cb_dbfa.SelectedValue).DataContext.ToString()
                             select service;
            dgDBFA.ItemsSource =serviceReq.ToList();
        }
    }
}
