﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lenovo_BL;
using Lenovo_Entities;
using Lenovo_Exception;

namespace Lenovo_Services
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Display();

        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            AddServices();
            //Display();
        }

        private bool ValidateUI()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (txt_id.Text == null || txt_id.Text == string.Empty)
            {
                isValid = false;
                sb.Append("ID is Empty!" + Environment.NewLine);
            }
            if (txt_date.Text == null || txt_date.Text == string.Empty)
            {
                isValid = false;
                sb.Append("date is Empty!" + Environment.NewLine);
            }
            if (txt_name.Text == string.Empty | txt_name.Text.Length < 1)
            {
                isValid = false;
                sb.Append("Name is Empty!" + Environment.NewLine);
            }
            if (txt_num.Text == null || txt_num.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Contact is Empty!" + Environment.NewLine);
            }
            if (cb_dt.SelectedIndex < 0)
            {
                isValid = false;
                sb.Append("DeviceType is Empty!" + Environment.NewLine);
            }
            if (txt_serial.Text == null || txt_serial.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Serial Number is Empty!" + Environment.NewLine);
            }
            if (txt_desc.Text == null || txt_desc.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Dsecription is Empty!" + Environment.NewLine);
            }

            return isValid;
        }

        private void AddServices()
        {
            try
            {

                string id;
                DateTime date;
                string name;
                string contact;
                string type;
                string serialno;
                string description;
                bool serviceAdded;
                //
                if (ValidateUI())
                {
                    id = (txt_id.Text);
                    date = Convert.ToDateTime(txt_date.SelectedDate);
                    name = txt_name.Text;
                    contact = txt_num.Text;
                    type = ((ComboBoxItem)cb_dt.SelectedValue).Content.ToString();
                    serialno = txt_serial.Text;
                    description = txt_desc.Text;
                    //


                    Services objs = new Services
                    {
                        ServiceID = id ,
                        Date = date,
                        OwnerName=name,
                        Contact=contact ,
                        DeviceType=type,
                        SerialNo=serialno,
                        IssueDescription=description
                        
                        
                    };
                    serviceAdded = ServicesBL.AddServicesBL(objs);
                    if (serviceAdded == true)
                    {
                        MessageBox.Show("service record Added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Service record not Added successfully.");
                        Display();
                    }
                }
                else
                {
                    MessageBox.Show("Validation Error!");
                }
            }
            catch (LException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Display()
        {
            try
            {
                List<Services> objs = ServicesBL.DisplayServicesBL();
                if (objs != null)
                {
                    dgservices.ItemsSource = objs.ToList();
                }
                else
                {
                    MessageBox.Show("No record available.");
                }
            }
            catch (LException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Grid_Loaded_1(object sender, RoutedEventArgs e)
        {
            Display();
        }
    }
}
