﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lenovo_Exception;
using Lenovo_Entities;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Lenovo_DAL
{
    public class servicesDAL
    {
        public bool AddServicesDAL(Services objServices) //Adding Services to DB and Returns Boolean Values
        {
            bool serviceAdded = false;
            SqlConnection objCon = null;
            SqlCommand objCom = null;
            try
            {
                //Make Connection
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["LenovoConnectionString"].ConnectionString);
                objCom = new SqlCommand("189782.InsertServiceRequestLRC", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ServiceID", objServices.ServiceID);
                SqlParameter objSqlParam_Date = new SqlParameter("@Date", objServices.Date);
                SqlParameter objSqlParam_OwnerName = new SqlParameter("@OwnerName", objServices.OwnerName);
                SqlParameter objSqlParam_Contact = new SqlParameter("@Contact", objServices.Contact);
                SqlParameter objSqlParam_DeviceType = new SqlParameter("@DeviceType", objServices.DeviceType);
                SqlParameter objSqlParam_SerialNo = new SqlParameter("@SerialNo", objServices.SerialNo);
                SqlParameter objSqlParam_Issue = new SqlParameter("@IssueDescription", objServices.IssueDescription);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Date);
                objCom.Parameters.Add(objSqlParam_OwnerName);
                objCom.Parameters.Add(objSqlParam_Contact);
                objCom.Parameters.Add(objSqlParam_DeviceType);
                objCom.Parameters.Add(objSqlParam_SerialNo);
                objCom.Parameters.Add(objSqlParam_Issue);
                // open connection and excute the procedure
                objCon.Open();
                objCom.ExecuteNonQuery();
                serviceAdded = true;
            }
            catch (SqlException objsqlEx)
            {
                throw new LException(objsqlEx.Message);
            }
            finally
            {
                //close the connection
                objCon.Close();
            }
            return serviceAdded;
        }

        public List<Services> DisplayServicesDAL() //Display the services which are added and returns boolen value
        {
                SqlConnection objCon = null;
                List<Services> objServices = new List<Services>();
                try
                {
                    //Make Connection
                    objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["LenovoConnectionString"].ConnectionString);
                    SqlCommand objCom = new SqlCommand("[189782].SelectServiceRequestLRC", objCon);
                    //open connection and excute the procedure
                    objCom.CommandType = CommandType.StoredProcedure;
                    objCon.Open();
                    //create object for datareader
                    SqlDataReader objDR = objCom.ExecuteReader();
                    while (objDR.Read())
                    {
                        Services objService = new Services();
                        objService.ServiceID = objDR[0] as string;
                        objService.Date = Convert.ToDateTime(objDR[1]);
                        objService.OwnerName = objDR[2] as string;
                        objService.Contact = objDR[3] as string;
                        objService.DeviceType = objDR[4] as string;
                        objService.SerialNo = objDR[5] as string;
                        objService.IssueDescription = objDR[6] as string;
                        objServices.Add(objService);
                    }
                    
                }
                catch (SqlException objSqlEx)
                {
                    throw new LException(objSqlEx.Message);
                }
                finally
                {
                    //close the connection
                    objCon.Close();
                }
                return objServices;
        }
    }
}
