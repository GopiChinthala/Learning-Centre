﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lenovo_DAL;
using Lenovo_Entities;
using Lenovo_Exception;
using System.Data;
using System.Text.RegularExpressions;

namespace Lenovo_BL
{
    public class ServicesBL
    {
        public static bool Validation(Services service)
        {
            //validation function
            bool isValid = true;
            StringBuilder objSB = new StringBuilder();
            //id validation
            if(service.ServiceID.Length > 6)
            {
                isValid = false;
                objSB.Append("\nID should be 6 Characters");
            }
            if (!Regex.Match(service.ServiceID, "^[S][R][0-9]{4}$").Success)
            {
                isValid = false;
                objSB.Append("\nstarting 2 characters should be alphabets");
            }

            if (service.Contact.Length > 10 && service.Contact.Length < 10)
            {
                isValid = false;
                objSB.Append( "\nContact number should be 10");
                    
            }
            if (!Regex.Match(service.Contact, "^[7-9]{1}[0-9]{9}$").Success)
            {
                isValid = false;
                objSB.Append("\nMobile number starts with 7,8 or 9");
            }
            if (service.DeviceType == string.Empty)
            {
                isValid = false;
                objSB.Append("\nYou can enter only Laptop,Mobile,Desktop...");
            }
            DateTime curdate = DateTime.Today;
            if (service.Date < curdate)
            {
                isValid = false;
                objSB.Append("\nInvalid date");
            }
            return isValid;
        }

        public static bool AddServicesBL(Services service)
        {
            bool serviceAdded = false;

            try
            {
                if (Validation(service))
                {
                    servicesDAL objDAL = new servicesDAL();
                    serviceAdded = objDAL.AddServicesDAL(service);
                }

            }
            catch (LException ex)
            {
                throw ex;
            }
            return serviceAdded;
        }

        public static List<Services> DisplayServicesBL()
        {
            List<Services> GetAllServices = null;
            try
            {
                servicesDAL objDAL = new servicesDAL();
                GetAllServices = objDAL.DisplayServicesDAL();
            }
            catch (LException ex)
            {
                throw ex;
            }
            return GetAllServices;
        }
    }
}
