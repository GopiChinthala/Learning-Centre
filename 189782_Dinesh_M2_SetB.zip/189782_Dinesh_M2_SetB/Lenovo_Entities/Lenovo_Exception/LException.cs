﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lenovo_Exception
{
    
    public class LException : ApplicationException

    { 
            public LException() : base() //initialize new instance
            {

            }
            public LException(string message) : base(message) //Parameterized
            {

            }
            public LException(string message, Exception innerException) : base(innerException: innerException, message: message) //Errors tha explains the reason of the exception
            {

            }
        
    }
}
