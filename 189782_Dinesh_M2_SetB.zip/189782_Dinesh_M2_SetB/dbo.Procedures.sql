﻿--drop procedure [189782].[InsertServiceRequestLRC]
--CREATE PROCEDURE [189782].[InsertServiceRequestLRC]

-- @ServiceID varchar(50),

--  @Date date,

--  @OwnerName varchar(50),

--  @Contact varchar(50),

--  @DeviceType varchar(50),

--  @SerialNo varchar(50),

--  @IssueDescription varchar(50)

--AS

--Begin

-- Insert into [189782].ServiceRequest_LRC values(@ServiceID, @Date, @OwnerName, @Contact, @DeviceType, @SerialNo, @IssueDescription)

--End

--drop procedure [189782].[SelectServiceRequestLRC]

--CREATE PROCEDURE [189782].[SelectServiceRequestLRC]

  

--AS

--Begin

-- select * from [189782].ServiceRequest_LRC;

--End